package com.qait.demo.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestLevel1_SnapDeal_Selenium_Imported_From_IDE_Broken_Needs_To_Be_Fixed {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl =  "https://www.snapdeal.com/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testECommerceSite() throws Exception {
		driver.get(baseUrl + "/");
		driver.manage().window().maximize();
		driver.findElement(By.id("inputValEnter")).click();
		driver.findElement(By.id("inputValEnter")).clear();
		driver.findElement(By.id("inputValEnter")).sendKeys("mobile");
		driver.findElement(By.xpath("//button[@onclick=\"submitSearchForm('go_header');\"]")).click();
		
		System.out.println(driver.getCurrentUrl());
		
		System.out.println(driver.getTitle());
		
		String parentWindow = driver.getWindowHandle();
		
		System.out.println(parentWindow);
		
		driver.findElement(By.xpath("(//img[contains(@class,'product-image')])[1]")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		
		System.out.println(driver.getWindowHandle());
		
		driver.switchTo().window(driver.getWindowHandle());
		
		System.out.println(driver.getTitle());
		
		
		driver.findElement(By.xpath("//div[@id='add-cart-button-id']/span")).click();
		
		driver.findElement(By.linkText("Proceed To Checkout")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		//driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			//fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
