package com.qait.automation.getpageobjects;

public enum Locators {
	id, name, classname, css, xpath, linktext;
}